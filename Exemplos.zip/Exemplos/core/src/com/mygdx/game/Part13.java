package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;


/**
 * TODO: Start here
 *
 * In this exercise we're going to connect the dots, but instead of drawing by hand, we're going to
 * use ShapeRenderer and polyline.
 *
 * TODO: Run what we've got so far
 *
 * As you can see, we've got some dots to work with, but no lines yet. Let's fix that!
 */

public class Part13 extends ApplicationAdapter {

    public class Dots {
        private final float[] FLOAT_DOTS = {411.0f, 237.0f, 388.0f, 272.0f, 355.0f, 296.0f, 314.0f, 312.0f, 278.0f, 318.0f, 247.0f, 319.0f, 209.0f, 317.0f, 195.0f, 306.0f, 163.0f, 271.0f, 159.0f, 243.0f, 159.0f, 200.0f, 174.0f, 178.0f, 202.0f, 169.0f, 224.0f, 169.0f, 226.0f, 187.0f, 211.0f, 188.0f, 189.0f, 197.0f, 188.0f, 207.0f, 191.0f, 233.0f, 212.0f, 234.0f, 216.0f, 212.0f, 216.0f, 191.0f, 219.0f, 145.0f, 255.0f, 140.0f, 274.0f, 158.0f, 272.0f, 171.0f, 277.0f, 186.0f, 309.0f, 188.0f, 323.0f, 176.0f, 323.0f, 158.0f, 333.0f, 147.0f, 368.0f, 141.0f, 389.0f, 144.0f, 395.0f, 167.0f, 395.0f, 195.0f, 397.0f, 215.0f, 390.0f, 235.0f};

        Array<Vector2> dots(){
            int dotCount = FLOAT_DOTS.length/2;
            Array<Vector2> dots = new Array<Vector2>(dotCount);
            for (int i = 0; i < dotCount; i++){
                Vector2 dot = new Vector2();
                dot.x = FLOAT_DOTS[2*i];
                dot.y = FLOAT_DOTS[2*i+1];
                dots.add(dot);
            }
            return dots;
        }
    }


    private static final float DOT_RADIUS = 3.0f;
    private SpriteBatch spriteBatch;
    private BitmapFont bitmapFont;
    private final Array<Vector2> dots = new Dots().dots();
    private float[] floatDots;
    private ShapeRenderer shapeRenderer;


    @Override
    public void create () {
        spriteBatch = new SpriteBatch();
        bitmapFont = new BitmapFont();
        floatDots = vector2ArrayToFloatArray(dots);
        shapeRenderer = new ShapeRenderer();
    }

    /**
     * TODO: Complete this function to translate Array<Vector2> to float[]
     *
     * The first problem is that the dot positions we have to work with are in an array of vectors,
     * and polyLine wants a flat array of floats. We've set up the array of floats for you, now all
     * you need to do is iterate over the Array of vectors, and put the x and y components into the
     * float array. Remember to check out the solution directory if you need help. This is a tricky
     * one!
     */
    private float[] vector2ArrayToFloatArray(Array<Vector2> dots){
        float[] floatDots = new float[dots.size * 2];
        int i = 0;
        for (Vector2 dot : dots){
            floatDots[i++] = dot.x;
            floatDots[i++] = dot.y;
        }
        return floatDots;
    }

    @Override
    public void render () {
        // Make the background black
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Draw the dots
        shapeRenderer.begin(ShapeType.Filled);
        for (Vector2 dot : dots){
            shapeRenderer.circle(dot.x, dot.y, DOT_RADIUS);
        }
        shapeRenderer.end();

        // Draw the numbers
        spriteBatch.begin();
        Integer i = 1;
        for (Vector2 dot : dots){
            bitmapFont.draw(spriteBatch,i.toString(),dot.x+DOT_RADIUS, dot.y-DOT_RADIUS);
            i++;
        }
        spriteBatch.end();

        // TODO: Start a batch with Shapetype.Line
        shapeRenderer.begin(ShapeType.Line);

        // TODO: Draw a polyline using the dot positions as a float array
        /*if (floatDots.length > 3) {
            shapeRenderer.polyline(floatDots);
        }
    */
        // TODO: End the batch
        shapeRenderer.end();


    }
}