package com.mygdx.game.eventos;

import com.badlogic.gdx.Game;

public class Part29 extends Game {

    @Override
    public void create() {
        setScreen(new BallScreen());
    }

}