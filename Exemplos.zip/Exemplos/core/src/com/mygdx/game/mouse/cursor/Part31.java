package com.mygdx.game.mouse.cursor;

import com.badlogic.gdx.Game;

public class Part31 extends Game {

    @Override
    public void create() {
        setScreen(new BallScreen());
    }

}