package com.mygdx.game.mouse;

import com.badlogic.gdx.Game;

public class Part30 extends Game {

    @Override
    public void create() {
        setScreen(new BallScreen());
    }

}