/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mygdx.game;

/**
 * @author coelho
 */

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Part9 implements ApplicationListener {
    private SpriteBatch batch;
    private BitmapFont font;
    private Music mp3Music;

    @Override
    public void create() {
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.setColor(Color.RED);
        //Sound mp3Sound = Gdx.audio.newSound(Gdx.files.internal("mp3.mp3"));
        mp3Music = Gdx.audio.newMusic(Gdx.files.internal("mp3.mp3"));
        mp3Music.play();


    }

    @Override
    public void dispose() {
        batch.dispose();
        font.dispose();
        mp3Music.dispose();
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();
        font.draw(batch, "Playing", 200, 200);
        batch.end();
        /*mp3Sound.play();

        final long id = mp3Sound.loop();
        Timer.schedule(new Timer.Task(){
            @Override
            public void run(){
                mp3Sound.stop(id);
            }
        }, 5.0f);
        */
        //mp3Music.setVolume(1.0f);
        //mp3Music.pause();
        //mp3Music.stop();
        Gdx.app.log("SONG", Float.toString(mp3Music.getPosition()));
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }
}