package com.mygdx.game.velocidade;

import com.badlogic.gdx.Game;

public class Part27 extends Game {

    @Override
    public void create() {
        setScreen(new BallScreen1());
    }

}