package com.mygdx.game.fps;

import com.badlogic.gdx.Game;

public class Part25 extends Game {

        @Override
        public void create() {
            setScreen(new FPSCounterScreen());
        }

    }