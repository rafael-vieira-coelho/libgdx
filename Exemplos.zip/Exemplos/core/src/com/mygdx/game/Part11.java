package com.mygdx.game;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

/**
 * TODO: Start here to learn more about ApplicationListener and ShapeRenderer

 * In this demo we're exploring ApplicationListener and ShapeRenderer. ApplicationListener is the
 * entry point into your code. To get some insight into the lifecycle of this object, we've inserted
 * log messages in each of the six required methods.

 * Logging is provided by the host application, and will appear in whatever output stream makes
 * sense for that application. For the desktop version, it'll be console output, for the Android
 * version, it'll go through the usual Android LogCat system.

 * There's a point on screen! And log messages showing the lifecycle of the ApplicationListener.
 */
public class Part11 implements ApplicationListener {

    // Always tag your log messages!
    public static final String TAG = Part11.class.getName();
    private ShapeRenderer shapeRenderer;

    /**
     * This is called when the application is ready for us to start up. Anything you'd do in a
     * constructor, do in create instead.
     */
    @Override
    public void create() {
        Gdx.app.log(TAG, "Application Listener Created");
        // Never allocate anything in render, since that gets called 60 times a second
        shapeRenderer = new ShapeRenderer();
    }

    /**
     * resize gets called right after create, and any time the screen size changes. This can happen
     * when a mobile device rotates, or if you drag around the size of the desktop window. We'll be
     * responding to resize in more interesting ways in the next level.
     */
    @Override
    public void resize(int width, int height) {
        Gdx.app.log(TAG, "Resized to width = " + width + " height = " + height);
    }

    /**
     * When Java finds that it's running out of memory, it performs a garbage collection to free up
     * memory held by objects that are no longer in use. Unfortunately, garbage collection is slow,
     * and nothing else can happen while the collection is in process. In a game, this can mean a
     * momentary freeze, which players hate with a burning passion. LibGDX does two things to avoid
     * this. First, there are a number of places where we need to manage our own memory. Since we
     * created a ShapeRenderer, we also need to dispose of it, as shown below.
     * <p>
     * The other way LibGDX avoids garbage collection hangs is by providing a ton of custom
     * collections that cleverly manage memory. We'll be using some of those soon.
     */
    @Override
    public void dispose() {
        Gdx.app.log(TAG, "Application Listener Disposed of");
        shapeRenderer.dispose();
    }

    /**
     * Render is where the action happens. By default, render will get called 60 times a second, and
     * it's the cue that it's time for our game to update itself and draw a new frame.
     */
    @Override
    public void render() {
        // Set the background color to opaque black
        Gdx.gl.glClearColor(0, 0, 0, 1);
        // Actually tell OpenGL to clear the screen
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        // First we begin a batch of points
        shapeRenderer.begin(ShapeType.Point);
        for (int i = 0; i < 100; i ++) {
            // Then we draw a point
            shapeRenderer.point(100 + i, 100, 0);
            shapeRenderer.point(100, 100 + i, 0);
        }
        // And make sure we end the batch
        shapeRenderer.end();
        //Now we dray a line
        shapeRenderer.begin(ShapeType.Line);
        shapeRenderer.setColor(Color.BLUE);
        shapeRenderer.line(200,200,0,400, 200, 0);
        shapeRenderer.setColor(Color.BLUE);
        // From one color to another
        shapeRenderer.line(10,400,400,400, Color.MAGENTA, Color.GOLD);
        //Opacity (Alpha component - a)
        shapeRenderer.setColor(0, 1, 0, 0.01f);
        shapeRenderer.line(10,300,400,300);
        //Multiple Lines: (x,y) pairs vertices => (x1, y1, x2, y2, ..., xn, yn)
        shapeRenderer.setColor(Color.PINK);
        float[] vertices = {420, 50, 400, 50, 420, 10, 400, 10};
        shapeRenderer.polyline(vertices);
        //Now we dray an arc
        shapeRenderer.setColor(Color.RED);
        shapeRenderer.arc(500f,10f, 100f,10f,100f);
        shapeRenderer.end();
        //Now we dray a circle
        shapeRenderer.begin(ShapeType.Filled);
        shapeRenderer.setColor(Color.GREEN);
        shapeRenderer.circle(300,300,70);
        shapeRenderer.circle(100,300,70, 10);
        shapeRenderer.end();
        shapeRenderer.begin(ShapeType.Line);
        shapeRenderer.circle(500,300,70);
        for (int radius = 80; radius > 0; radius -= 10) {
            shapeRenderer.circle(300,100,radius);
        }
        shapeRenderer.end();
    }

    /**
     * Called when the game loses focus, or when it's about to be destroyed. This is the time to
     * save any state you want to persist.
     */
    @Override
    public void pause() {
        Gdx.app.log(TAG, "Paused");
    }

    /**
     * Called when the game regains focus after being paused. This is mostly relevant on Android,
     * where the game can be paused by pressing the home button, but dispose is not called. When the
     * game is relaunched, resume will be called.
     */
    @Override
    public void resume() {
        Gdx.app.log(TAG, "Resumed");
    }
}
