package com.mygdx.game.teclado;

import com.badlogic.gdx.Game;

public class Part28 extends Game {

    @Override
    public void create() {
        setScreen(new BallScreen());
    }

}