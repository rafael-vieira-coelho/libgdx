package com.mygdx.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mygdx.game.*;
import com.mygdx.game.eventos.Part29;
import com.mygdx.game.fps.Part25;
import com.mygdx.game.gravidade.Part26;
import com.mygdx.game.mouse.Part30;
import com.mygdx.game.mouse.cursor.Part31;
import com.mygdx.game.screens.Part23;
import com.mygdx.game.teclado.Part28;
import com.mygdx.game.usando_games.Part24;
import com.mygdx.game.velocidade.Part27;

import java.util.Scanner;

/*
https://github.com/libgdx
https://libgdx.badlogicgames.com/download.html
https://libgdx.badlogicgames.com/documentation/gettingstarted/Creating%20Projects.html
https://www.gamefromscratch.com/page/LibGDX-Tutorial-series.aspx
 */
public class DesktopLauncher {
    public static void main(String[] arg) {
        Scanner s = new Scanner(System.in);
        LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
        System.out.println("MENU: \n " +
                " 1 - Olá Mundo \n " +
                " 2 - Usando Spritesheet \n " +
                " 3 - Desenhando o Sprite \n " +
                " 4 - Criando Animação \n " +
                " 5 - Entrada Teclado \n " +
                " 6 - Entrada Mouse \n " +
                " 7 - Mouse/Teclado \n " +
                " 8 - Usando Camêra \n " +
                " 9 - Audio \n" +
                " 10 - Ponto na Tela \n" +
                " 11 - Desenha Formas \n" +
                " 12 - Céu Estrelado \n" +
                " 13 - Junto os Pontos \n" +
                " 14 - Espiral \n" +
                " 15 - Retângulos\n" +
                " 16 - Flor com Retângulos \n" +
                " 17 - Escreve Texto \n" +
                " 18 - Move Círculo \n" +
                " 19 - Gera Pontos \n" +
                " 20 - Move Câmera \n" +
                " 21 - Usando a Câmera \n" +
                " 22 - Movimento circular no tempo \n" +
                " 23 - Usando telas diferentes (tecla espaço) \n" +
                " 24 - Trocando ApplicationAdapter para Game \n" +
                " 25 - Calculando FPS (Frames Per Second) \n" +
                " 26 - Objetos caindo (gravidade) \n" +
                " 27 - Bola que saltam (velocidade) \n" +
                " 28 - Controle com teclado (polling) \n" +
                " 29 - Controle através de eventos \n" +
                " 30 - Controle através do mouse (clique na bola e arraste) \n" +
                " 31 - Controle através do mouse (segue o cursor) \n" +
                " Opção:");
        int op = s.nextInt();

        switch (op) {
            case 1:
                new LwjglApplication(new Part1(), config);
                break;
            case 2:
                new LwjglApplication(new Part2(), config);
                break;
            case 3:
                new LwjglApplication(new Part3(), config);
                break;
            case 4:
                new LwjglApplication(new Part4(), config);
                break;
            case 5:
                new LwjglApplication(new Part5(), config);
                break;
            case 6:
                new LwjglApplication(new Part6(), config);
                break;
            case 7:
                new LwjglApplication(new Part7(), config);
                break;
            case 8:
                new LwjglApplication(new Part8(), config);
                break;
            case 9:
                new LwjglApplication(new Part9(), config);
                break;
            case 10:
                new LwjglApplication(new Part10(), config);
                break;
            case 11:
                new LwjglApplication(new Part11(), config);
                break;
            case 12:
                new LwjglApplication(new Part12(), config);
                break;
            case 13:
                new LwjglApplication(new Part13(), config);
                break;
            case 14:
                new LwjglApplication(new Part14(), config);
                break;
            case 15:
                new LwjglApplication(new Part15(), config);
                break;
            case 16:
                new LwjglApplication(new Part16(), config);
                break;
            case 17:
                new LwjglApplication(new Part17(), config);
                break;
            case 18:
                new LwjglApplication(new Part18(), config);
                break;
            case 19:
                new LwjglApplication(new Part19(), config);
                break;
            case 20:
                new LwjglApplication(new Part20(), config);
                break;
            case 21:
                new LwjglApplication(new Part21(), config);
                break;
            case 22:
                new LwjglApplication(new Part22(), config);
                break;
            case 23:
                new LwjglApplication(new Part23(), config);
                break;
            case 24:
                new LwjglApplication(new Part24(), config);
                break;
            case 25:
                new LwjglApplication(new Part25(), config);
                break;
            case 26:
                new LwjglApplication(new Part26(), config);
                break;
            case 27:
                new LwjglApplication(new Part27(), config);
                break;
            case 28:
                new LwjglApplication(new Part28(), config);
                break;
            case 29:
                new LwjglApplication(new Part29(), config);
                break;
            case 30:
                new LwjglApplication(new Part30(), config);
                break;
            case 31:
                new LwjglApplication(new Part31(), config);
                break;
        }
    }
}
